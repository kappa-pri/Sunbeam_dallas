#if UNITY_EDITOR
using TMPro;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

/// <summary>
/// Builds the entire Pack the Cooler scene, prefabs included, from one menu item.
/// Landscape 1920x1080 for desktop.
/// This file must live in a folder named "Editor". Delete it once the scene exists.
/// </summary>
public static class CoolerSceneBuilder
{
    private const string PrefabFolder = "Assets/Prefabs";
    private const string RootName = "Pack The Cooler";

    // Where the ice sits inside the cooler artwork, as a fraction of the image.
    // Measured from the supplied cooler PNG; nudge CoolerRoot's anchors if you redraw it.
    private static readonly Vector2 InteriorMin = new Vector2(0.15f, 0.22f);
    private static readonly Vector2 InteriorMax = new Vector2(0.83f, 0.54f);

    private const float CellSize = 120f;
    private const float CellGap = 12f;

    private static readonly Color Sky = new Color(0.55f, 0.82f, 0.91f);
    private static readonly Color Sand = new Color(0.96f, 0.89f, 0.77f);
    private static readonly Color Deep = new Color(0.07f, 0.27f, 0.35f);
    private static readonly Color Accent = new Color(1f, 0.45f, 0.55f);

    [MenuItem("Tools/Pack the Cooler/Build Scene")]
    public static void Build()
    {
        if (TMP_Settings.defaultFontAsset == null)
        {
            EditorUtility.DisplayDialog(
                "TextMeshPro not set up",
                "Import TMP Essential Resources first:\nWindow > TextMeshPro > Import TMP Essential Resources\n\nThen run this again.",
                "OK");
            return;
        }

        GameObject existing = GameObject.Find(RootName);
        if (existing != null)
        {
            if (!EditorUtility.DisplayDialog("Rebuild scene?",
                    $"'{RootName}' already exists. Replacing it will clear any artwork you've assigned.",
                    "Replace", "Cancel"))
                return;
            Object.DestroyImmediate(existing);
        }

        if (!AssetDatabase.IsValidFolder(PrefabFolder))
            AssetDatabase.CreateFolder("Assets", "Prefabs");

        EnsureEventSystem();

        Sprite panel = AssetDatabase.GetBuiltinExtraResource<Sprite>("UI/Skin/UISprite.psd");
        Sprite knob = AssetDatabase.GetBuiltinExtraResource<Sprite>("UI/Skin/Knob.psd");

        PackableItem itemPrefab = BuildItemPrefab(panel);
        CoolerSlot slotPrefab = BuildSlotPrefab(panel);
        ListRow rowPrefab = BuildListRowPrefab(knob);

        // ---- Canvas (landscape) ----
        GameObject canvasGO = new GameObject(RootName,
            typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
        Canvas canvas = canvasGO.GetComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;

        CanvasScaler scaler = canvasGO.GetComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1920f, 1080f);
        scaler.matchWidthOrHeight = 0.5f;

        RectTransform root = (RectTransform)canvasGO.transform;

        // ================= START SCREEN =================
        RectTransform startPanel = NewRect("StartPanel", root);
        Stretch(startPanel, Vector2.zero, Vector2.one);

        RectTransform startBg = NewRect("StartBackground", startPanel);
        Stretch(startBg, Vector2.zero, Vector2.one);
        AddImage(startBg, null, Sky, false);

        RectTransform startBtnRect = NewRect("StartButton", startPanel);
        startBtnRect.anchorMin = startBtnRect.anchorMax = new Vector2(0.5f, 0.28f);
        startBtnRect.pivot = new Vector2(0.5f, 0.5f);
        startBtnRect.sizeDelta = new Vector2(520f, 170f);
        Image startImg = AddImage(startBtnRect, panel, Accent, true);
        startImg.preserveAspect = true;
        Button startBtn = startBtnRect.gameObject.AddComponent<Button>();
        startBtn.targetGraphic = startImg;

        TMP_Text startLabel = AddText(startBtnRect, "PlaceholderLabel", "Start", 52,
            Color.white, TextAlignmentOptions.Center);
        Stretch((RectTransform)startLabel.transform, Vector2.zero, Vector2.one);

        // ================= GAME SCREEN =================
        RectTransform gamePanel = NewRect("GamePanel", root);
        Stretch(gamePanel, Vector2.zero, Vector2.one);

        RectTransform bg = NewRect("Background", gamePanel);
        Stretch(bg, Vector2.zero, Vector2.one);
        AddImage(bg, null, Sand, false);
        RectTransform skyRect = NewRect("Sky", bg);
        Stretch(skyRect, new Vector2(0f, 0.42f), Vector2.one);
        AddImage(skyRect, null, Sky, false);

        // Header
        RectTransform header = NewRect("Header", gamePanel);
        Stretch(header, new Vector2(0.03f, 0.895f), new Vector2(0.97f, 0.975f));
        TMP_Text title = AddText(header, "Title", "Pack the cooler", 52, Deep, TextAlignmentOptions.Left);
        Stretch((RectTransform)title.transform, Vector2.zero, new Vector2(0.6f, 1f));
        TMP_Text timerText = AddText(header, "Timer", "0:00", 44, Deep, TextAlignmentOptions.Right);
        Stretch((RectTransform)timerText.transform, new Vector2(0.6f, 0f), Vector2.one);

        // Left column: shopping list
        RectTransform listPanel = NewRect("ListPanel", gamePanel);
        Stretch(listPanel, new Vector2(0.030f, 0.06f), new Vector2(0.255f, 0.87f));
        AddImage(listPanel, panel, new Color(1f, 1f, 1f, 0.72f), false);

        TMP_Text listTitle = AddText(listPanel, "ListTitle", "Shopping list", 34, Deep, TextAlignmentOptions.Left);
        Stretch((RectTransform)listTitle.transform, new Vector2(0.06f, 0.88f), new Vector2(0.94f, 0.97f));

        RectTransform listRoot = NewRect("ListRoot", listPanel);
        Stretch(listRoot, new Vector2(0.04f, 0.04f), new Vector2(0.96f, 0.86f));
        VerticalLayoutGroup vlg = listRoot.gameObject.AddComponent<VerticalLayoutGroup>();
        vlg.spacing = 8f;
        vlg.childControlWidth = true;
        vlg.childControlHeight = false;
        vlg.childForceExpandHeight = false;

        // Centre: cooler artwork with the slot grid over the ice
        RectTransform coolerArea = NewRect("CoolerArea", gamePanel);
        Stretch(coolerArea, new Vector2(0.285f, 0.06f), new Vector2(0.705f, 0.87f));

        TMP_Text capacityText = AddText(coolerArea, "Capacity", "0/8", 34, Deep, TextAlignmentOptions.Center);
        Stretch((RectTransform)capacityText.transform, new Vector2(0f, 0.93f), new Vector2(1f, 1f));

        RectTransform coolerArt = NewRect("CoolerArt", coolerArea);
        Stretch(coolerArt, new Vector2(0f, 0f), new Vector2(1f, 0.91f));
        Image coolerImg = AddImage(coolerArt, panel, new Color(1f, 0.72f, 0.78f), false);
        coolerImg.preserveAspect = true;
        AspectRatioFitter fitter = coolerArt.gameObject.AddComponent<AspectRatioFitter>();
        fitter.aspectMode = AspectRatioFitter.AspectMode.FitInParent;
        fitter.aspectRatio = 1f;

        RectTransform coolerRoot = NewRect("CoolerRoot", coolerArt);
        Stretch(coolerRoot, InteriorMin, InteriorMax);
        AddGrid(coolerRoot, 4);

        // Right column: the counter
        RectTransform trayPanel = NewRect("TrayPanel", gamePanel);
        Stretch(trayPanel, new Vector2(0.735f, 0.06f), new Vector2(0.970f, 0.87f));
        AddImage(trayPanel, panel, new Color(1f, 1f, 1f, 0.55f), false);

        TMP_Text trayLabel = AddText(trayPanel, "TrayLabel", "On the counter", 32, Deep, TextAlignmentOptions.Center);
        Stretch((RectTransform)trayLabel.transform, new Vector2(0.04f, 0.90f), new Vector2(0.96f, 0.98f));

        RectTransform trayRoot = NewRect("TrayRoot", trayPanel);
        Stretch(trayRoot, new Vector2(0.03f, 0.02f), new Vector2(0.97f, 0.88f));
        AddGrid(trayRoot, 3);

        // Win panel
        RectTransform winPanel = NewRect("WinPanel", gamePanel);
        winPanel.anchorMin = winPanel.anchorMax = new Vector2(0.5f, 0.5f);
        winPanel.sizeDelta = new Vector2(760f, 420f);
        AddImage(winPanel, panel, new Color(1f, 1f, 1f, 0.97f), true);

        TMP_Text winTitle = AddText(winPanel, "WinTitle", "Cooler packed!", 60, Accent, TextAlignmentOptions.Center);
        Stretch((RectTransform)winTitle.transform, new Vector2(0.05f, 0.62f), new Vector2(0.95f, 0.92f));
        TMP_Text winSummary = AddText(winPanel, "WinSummary", "", 38, Deep, TextAlignmentOptions.Center);
        Stretch((RectTransform)winSummary.transform, new Vector2(0.05f, 0.44f), new Vector2(0.95f, 0.60f));

        Button againBtn = MakeButton(winPanel, "PlayAgain", "Play again", panel, Accent,
            new Vector2(0.08f, 0.10f), new Vector2(0.48f, 0.36f));
        Button menuBtn = MakeButton(winPanel, "MenuButton", "Menu", panel, Deep,
            new Vector2(0.52f, 0.10f), new Vector2(0.92f, 0.36f));

        // Board lives outside GamePanel so its coroutines keep running while hidden.
        GameObject boardGO = new GameObject("Board");
        boardGO.transform.SetParent(root, false);
        CoolerBoard board = boardGO.AddComponent<CoolerBoard>();
        board.LoadDefaultContent();

        SerializedObject so = new SerializedObject(board);
        so.FindProperty("startPanel").objectReferenceValue = startPanel.gameObject;
        so.FindProperty("gamePanel").objectReferenceValue = gamePanel.gameObject;
        so.FindProperty("itemPrefab").objectReferenceValue = itemPrefab;
        so.FindProperty("slotPrefab").objectReferenceValue = slotPrefab;
        so.FindProperty("listRowPrefab").objectReferenceValue = rowPrefab;
        so.FindProperty("trayRoot").objectReferenceValue = trayRoot;
        so.FindProperty("coolerRoot").objectReferenceValue = coolerRoot;
        so.FindProperty("listRoot").objectReferenceValue = listRoot;
        so.FindProperty("timerText").objectReferenceValue = timerText;
        so.FindProperty("capacityText").objectReferenceValue = capacityText;
        so.FindProperty("winPanel").objectReferenceValue = winPanel.gameObject;
        so.FindProperty("winSummaryText").objectReferenceValue = winSummary;
        so.ApplyModifiedPropertiesWithoutUndo();

        UnityEditor.Events.UnityEventTools.AddPersistentListener(startBtn.onClick, board.StartGame);
        UnityEditor.Events.UnityEventTools.AddPersistentListener(againBtn.onClick, board.NewGame);
        UnityEditor.Events.UnityEventTools.AddPersistentListener(menuBtn.onClick, board.ReturnToStart);

        winPanel.gameObject.SetActive(false);
        gamePanel.gameObject.SetActive(false);
        startPanel.gameObject.SetActive(true);

        Undo.RegisterCreatedObjectUndo(canvasGO, "Build Cooler Scene");
        EditorSceneManager.MarkSceneDirty(EditorSceneManager.GetActiveScene());
        Selection.activeGameObject = canvasGO;

        Debug.Log("[CoolerSceneBuilder] Scene built. Assign your artwork to StartBackground, StartButton and CoolerArt, then press Play.");
    }

    // ---- Prefab builders ----

    private static PackableItem BuildItemPrefab(Sprite panel)
    {
        GameObject go = new GameObject("Item", typeof(RectTransform));
        RectTransform rect = (RectTransform)go.transform;
        rect.sizeDelta = new Vector2(CellSize, CellSize);

        RectTransform ring = NewRect("Ring", rect);
        Stretch(ring, Vector2.zero, Vector2.one, -9f);
        AddImage(ring, panel, Accent, false);

        RectTransform body = NewRect("Body", rect);
        Stretch(body, Vector2.zero, Vector2.one);
        Image bodyImg = AddImage(body, panel, new Color(0.42f, 0.76f, 0.87f), true);

        RectTransform icon = NewRect("Icon", rect);
        icon.anchorMin = icon.anchorMax = new Vector2(0.5f, 0.5f);
        icon.sizeDelta = new Vector2(CellSize * 0.72f, CellSize * 0.72f);
        Image iconImg = AddImage(icon, null, Color.white, false);
        iconImg.preserveAspect = true;
        iconImg.enabled = false;

        TMP_Text label = AddText(rect, "Label", "Water", 24, Color.white, TextAlignmentOptions.Center);
        Stretch((RectTransform)label.transform, new Vector2(0.08f, 0.08f), new Vector2(0.92f, 0.92f));
        label.enableAutoSizing = true;
        label.fontSizeMin = 12f;
        label.fontSizeMax = 28f;

        Button button = go.AddComponent<Button>();
        button.targetGraphic = bodyImg;

        PackableItem item = go.AddComponent<PackableItem>();
        SerializedObject so = new SerializedObject(item);
        so.FindProperty("background").objectReferenceValue = bodyImg;
        so.FindProperty("iconImage").objectReferenceValue = iconImg;
        so.FindProperty("label").objectReferenceValue = label;
        so.FindProperty("selectionRing").objectReferenceValue = ring.gameObject;
        so.ApplyModifiedPropertiesWithoutUndo();

        ring.gameObject.SetActive(false);
        return SaveAsPrefab(go, $"{PrefabFolder}/Item.prefab").GetComponent<PackableItem>();
    }

    private static CoolerSlot BuildSlotPrefab(Sprite panel)
    {
        GameObject go = new GameObject("Slot", typeof(RectTransform));
        RectTransform rect = (RectTransform)go.transform;
        rect.sizeDelta = new Vector2(CellSize, CellSize);

        Image img = AddImage(rect, panel, new Color(1f, 1f, 1f, 0.22f), true);

        Button button = go.AddComponent<Button>();
        button.targetGraphic = img;

        CoolerSlot slot = go.AddComponent<CoolerSlot>();
        SerializedObject so = new SerializedObject(slot);
        so.FindProperty("background").objectReferenceValue = img;
        so.ApplyModifiedPropertiesWithoutUndo();

        return SaveAsPrefab(go, $"{PrefabFolder}/Slot.prefab").GetComponent<CoolerSlot>();
    }

    private static ListRow BuildListRowPrefab(Sprite knob)
    {
        GameObject go = new GameObject("ListRow", typeof(RectTransform));
        RectTransform rect = (RectTransform)go.transform;
        rect.sizeDelta = new Vector2(0f, 56f);

        LayoutElement le = go.AddComponent<LayoutElement>();
        le.preferredHeight = 56f;

        HorizontalLayoutGroup h = go.AddComponent<HorizontalLayoutGroup>();
        h.spacing = 12f;
        h.childControlWidth = true;
        h.childControlHeight = true;
        h.childForceExpandWidth = false;
        h.padding = new RectOffset(12, 12, 4, 4);

        RectTransform check = NewRect("Check", rect);
        Image checkImg = AddImage(check, knob, new Color(1f, 1f, 1f, 0.35f), false);
        LayoutElement checkLE = check.gameObject.AddComponent<LayoutElement>();
        checkLE.preferredWidth = 34f;
        checkLE.preferredHeight = 34f;

        TMP_Text nameText = AddText(rect, "Name", "Water", 28, Deep, TextAlignmentOptions.Left);
        nameText.gameObject.AddComponent<LayoutElement>().flexibleWidth = 1f;

        TMP_Text countText = AddText(rect, "Count", "0/2", 28, Deep, TextAlignmentOptions.Right);
        countText.gameObject.AddComponent<LayoutElement>().preferredWidth = 90f;

        ListRow row = go.AddComponent<ListRow>();
        SerializedObject so = new SerializedObject(row);
        so.FindProperty("nameText").objectReferenceValue = nameText;
        so.FindProperty("countText").objectReferenceValue = countText;
        so.FindProperty("checkBox").objectReferenceValue = checkImg;
        so.ApplyModifiedPropertiesWithoutUndo();

        return SaveAsPrefab(go, $"{PrefabFolder}/ListRow.prefab").GetComponent<ListRow>();
    }

    // ---- Small helpers ----

    private static Button MakeButton(RectTransform parent, string name, string label,
        Sprite panel, Color color, Vector2 min, Vector2 max)
    {
        RectTransform rect = NewRect(name, parent);
        Stretch(rect, min, max);
        Image img = AddImage(rect, panel, color, true);
        Button btn = rect.gameObject.AddComponent<Button>();
        btn.targetGraphic = img;
        TMP_Text text = AddText(rect, "Label", label, 32, Color.white, TextAlignmentOptions.Center);
        Stretch((RectTransform)text.transform, Vector2.zero, Vector2.one);
        return btn;
    }

    private static GameObject SaveAsPrefab(GameObject go, string path)
    {
        GameObject asset = PrefabUtility.SaveAsPrefabAsset(go, path);
        Object.DestroyImmediate(go);
        return asset;
    }

    private static RectTransform NewRect(string name, Transform parent)
    {
        GameObject go = new GameObject(name, typeof(RectTransform));
        go.transform.SetParent(parent, false);
        return (RectTransform)go.transform;
    }

    private static void Stretch(RectTransform r, Vector2 min, Vector2 max, float inset = 0f)
    {
        r.anchorMin = min;
        r.anchorMax = max;
        r.offsetMin = new Vector2(inset, inset);
        r.offsetMax = new Vector2(-inset, -inset);
    }

    private static Image AddImage(RectTransform rect, Sprite sprite, Color color, bool raycast)
    {
        Image img = rect.gameObject.AddComponent<Image>();
        if (sprite != null)
        {
            img.sprite = sprite;
            img.type = Image.Type.Sliced;
        }
        img.color = color;
        img.raycastTarget = raycast;
        return img;
    }

    private static TMP_Text AddText(RectTransform parent, string name, string content,
        float size, Color color, TextAlignmentOptions align)
    {
        RectTransform rect = NewRect(name, parent);
        Stretch(rect, Vector2.zero, Vector2.one);
        TextMeshProUGUI text = rect.gameObject.AddComponent<TextMeshProUGUI>();
        text.text = content;
        text.fontSize = size;
        text.color = color;
        text.alignment = align;
        text.raycastTarget = false;
        return text;
    }

    private static void AddGrid(RectTransform rect, int columns)
    {
        GridLayoutGroup grid = rect.gameObject.AddComponent<GridLayoutGroup>();
        grid.cellSize = new Vector2(CellSize, CellSize);
        grid.spacing = new Vector2(CellGap, CellGap);
        grid.constraint = GridLayoutGroup.Constraint.FixedColumnCount;
        grid.constraintCount = columns;
        grid.childAlignment = TextAnchor.MiddleCenter;
    }

    private static void EnsureEventSystem()
    {
#if UNITY_2022_2_OR_NEWER
        if (Object.FindAnyObjectByType<EventSystem>() != null) return;
#else
        if (Object.FindObjectOfType<EventSystem>() != null) return;
#endif
        GameObject go = new GameObject("EventSystem", typeof(EventSystem));

        // Projects on the new Input System need a different module, or nothing clicks.
        System.Type newModule = System.Type.GetType(
            "UnityEngine.InputSystem.UI.InputSystemUIInputModule, Unity.InputSystem");
        if (newModule != null) go.AddComponent(newModule);
        else go.AddComponent<StandaloneInputModule>();
    }
}
#endif
