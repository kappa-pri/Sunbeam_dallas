using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// A single packable item. Lives in the tray until it's placed, then becomes a
/// child of a CoolerSlot. Clicking it either selects it or takes it back out.
/// </summary>
[RequireComponent(typeof(Button))]
public class PackableItem : MonoBehaviour
{
    [Header("Visuals")]
    [SerializeField] private Image background;
    [SerializeField] private Image iconImage;
    [SerializeField] private TMP_Text label;
    [SerializeField] private GameObject selectionRing;

    [Header("Feel")]
    [SerializeField] private float selectedScale = 1.08f;
    [SerializeField] private float selectedTilt = -4f;
    [SerializeField] private float travelDuration = 0.22f;
    [SerializeField] private float arcHeight = 70f;

    public string ItemId { get; private set; }
    public CoolerSlot Slot { get; private set; }
    public bool IsPacked => Slot != null;
    public bool IsAnimating { get; private set; }

    private CoolerBoard board;
    private RectTransform rect;
    private Button button;

    private void Awake()
    {
        rect = (RectTransform)transform;
        button = GetComponent<Button>();
        button.onClick.AddListener(HandleClick);
    }

    public void Setup(CoolerBoard owner, PackItem data)
    {
        board = owner;
        ItemId = data.id;
        Slot = null;
        IsAnimating = false;

        if (data.icon != null)
        {
            iconImage.sprite = data.icon;
            iconImage.enabled = true;
            if (label != null) label.text = string.Empty;
        }
        else
        {
            if (iconImage != null) iconImage.enabled = false;
            if (label != null) label.text = data.displayName;
        }

        if (background != null) background.color = data.tint;
        SetSelected(false);
    }

    private void HandleClick()
    {
        if (IsAnimating || board == null) return;
        board.ItemClicked(this);
    }

    public void SetSelected(bool selected)
    {
        if (selectionRing != null) selectionRing.SetActive(selected);
        rect.localScale = Vector3.one * (selected ? selectedScale : 1f);
        rect.localRotation = Quaternion.Euler(0f, 0f, selected ? selectedTilt : 0f);
    }

    /// <summary>Reparents into the slot and arcs to its centre.</summary>
    public IEnumerator MoveInto(CoolerSlot slot)
    {
        IsAnimating = true;
        SetSelected(false);
        Slot = slot;

        // Remember where it is on screen, reparent, then restore that position
        // so the animation starts from where the player last saw it.
        Vector3 worldPos = rect.position;
        rect.SetParent(slot.ContentRoot, false);
        rect.anchorMin = rect.anchorMax = new Vector2(0.5f, 0.5f);
        rect.pivot = new Vector2(0.5f, 0.5f);
        rect.position = worldPos;

        Vector2 start = rect.anchoredPosition;
        float t = 0f;
        while (t < travelDuration)
        {
            t += Time.deltaTime;
            float k = Mathf.Clamp01(t / travelDuration);
            float eased = 1f - (1f - k) * (1f - k);
            Vector2 pos = Vector2.Lerp(start, Vector2.zero, eased);
            pos.y += Mathf.Sin(eased * Mathf.PI) * arcHeight;
            rect.anchoredPosition = pos;
            yield return null;
        }

        rect.anchoredPosition = Vector2.zero;
        rect.localScale = Vector3.one;
        IsAnimating = false;
    }

    /// <summary>Back to the counter. The tray's layout group handles placement.</summary>
    public void ReturnTo(RectTransform tray)
    {
        Slot = null;
        SetSelected(false);
        rect.SetParent(tray, false);
        rect.localScale = Vector3.one;
        rect.localRotation = Quaternion.identity;
        StartCoroutine(PopRoutine());
    }

    private IEnumerator PopRoutine()
    {
        IsAnimating = true;
        yield return ScaleUniform(0.7f, 1f, 0.14f);
        IsAnimating = false;
    }

    private IEnumerator ScaleUniform(float from, float to, float duration)
    {
        float t = 0f;
        while (t < duration)
        {
            t += Time.deltaTime;
            float k = Mathf.Clamp01(t / duration);
            float s = Mathf.Lerp(from, to, k);
            rect.localScale = new Vector3(s, s, 1f);
            yield return null;
        }
        rect.localScale = Vector3.one;
    }
}
