using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

/// <summary>
/// Runs the round. Click an item to pick it up, click an empty slot to pack it,
/// click a packed item to put it back. Win by matching the shopping list exactly.
/// </summary>
public class CoolerBoard : MonoBehaviour
{
    [Header("Screens")]
    [SerializeField] private GameObject startPanel;
    [SerializeField] private GameObject gamePanel;
    [Tooltip("Skip the title screen and drop straight into a round. Handy while testing.")]
    [SerializeField] private bool skipStartScreen = false;

    [Header("Prefabs")]
    [SerializeField] private PackableItem itemPrefab;
    [SerializeField] private CoolerSlot slotPrefab;
    [SerializeField] private ListRow listRowPrefab;

    [Header("Containers")]
    [SerializeField] private RectTransform trayRoot;
    [SerializeField] private RectTransform coolerRoot;
    [SerializeField] private RectTransform listRoot;

    [Header("Rules")]
    [Min(1)]
    [SerializeField] private int coolerCapacity = 8;
    [Tooltip("On: unlisted items and over-packing block the win. Off: just meet the minimums.")]
    [SerializeField] private bool requireExactPack = true;

    [Header("Content")]
    [SerializeField] private List<PackItem> catalog = new List<PackItem>();
    [Tooltip("What starts on the counter. Include extras the list doesn't want.")]
    [SerializeField] private List<PackEntry> trayContents = new List<PackEntry>();
    [SerializeField] private List<PackEntry> shoppingList = new List<PackEntry>();

    [Header("HUD (all optional)")]
    [SerializeField] private TMP_Text timerText;
    [SerializeField] private TMP_Text capacityText;
    [SerializeField] private GameObject winPanel;
    [SerializeField] private TMP_Text winSummaryText;

    [Header("Audio (all optional)")]
    [SerializeField] private AudioSource audioSource;
    [SerializeField] private AudioClip selectClip;
    [SerializeField] private AudioClip packClip;
    [SerializeField] private AudioClip unpackClip;
    [SerializeField] private AudioClip winClip;

    private readonly List<PackableItem> items = new List<PackableItem>();
    private readonly List<CoolerSlot> slots = new List<CoolerSlot>();
    private readonly List<ListRow> rows = new List<ListRow>();

    private PackableItem selected;
    private bool inputLocked = true;
    private bool running;
    private float elapsed;

    public bool HasSelection => selected != null;

    private void Reset()
    {
        LoadDefaultContent();
    }

    private void Awake()
    {
        if (catalog.Count == 0 || trayContents.Count == 0 || shoppingList.Count == 0)
            LoadDefaultContent();
    }

    private void Start()
    {
        if (startPanel != null && !skipStartScreen)
        {
            startPanel.SetActive(true);
            if (gamePanel != null) gamePanel.SetActive(false);
        }
        else
        {
            StartGame();
        }
    }

    private void Update()
    {
        if (!running) return;
        elapsed += Time.deltaTime;
        if (timerText != null) timerText.text = FormatTime(elapsed);
    }

    /// <summary>Fills in the default summer puzzle. Also called by the scene builder.</summary>
    public void LoadDefaultContent()
    {
        catalog = new List<PackItem>
        {
            new PackItem("WATER",     "Water",      "#6EC6E8"),
            new PackItem("SODA",      "Soda",       "#FF6B81"),
            new PackItem("MELON",     "Watermelon", "#3DBE8B"),
            new PackItem("SANDWICH",  "Sandwich",   "#FFD166"),
            new PackItem("GRAPES",    "Grapes",     "#B8A9E0"),
            new PackItem("ICEPACK",   "Ice pack",   "#A8E6F0"),
            new PackItem("SUNSCREEN", "Sunscreen",  "#FF9F5A"),
            new PackItem("PHONE",     "Phone",      "#8C9BA5"),
        };

        trayContents = new List<PackEntry>
        {
            new PackEntry("WATER", 3),
            new PackEntry("SODA", 2),
            new PackEntry("MELON", 1),
            new PackEntry("SANDWICH", 2),
            new PackEntry("GRAPES", 1),
            new PackEntry("ICEPACK", 1),
            new PackEntry("SUNSCREEN", 1),
            new PackEntry("PHONE", 1),
        };

        shoppingList = new List<PackEntry>
        {
            new PackEntry("WATER", 2),
            new PackEntry("SODA", 2),
            new PackEntry("MELON", 1),
            new PackEntry("SANDWICH", 1),
        };
    }

    // ---- Public hooks (wire to Buttons) ----

    /// <summary>Title screen "Start" button.</summary>
    public void StartGame()
    {
        if (startPanel != null) startPanel.SetActive(false);
        if (gamePanel != null) gamePanel.SetActive(true);
        NewGame();
    }

    /// <summary>Win screen "Menu" button.</summary>
    public void ReturnToStart()
    {
        StopAllCoroutines();
        running = false;
        inputLocked = true;
        selected = null;

        if (winPanel != null) winPanel.SetActive(false);
        if (gamePanel != null) gamePanel.SetActive(false);
        if (startPanel != null) startPanel.SetActive(true);
    }

    public void NewGame()
    {
        StopAllCoroutines();
        StartCoroutine(Build());
    }

    // ---- Build ----

    private IEnumerator Build()
    {
        inputLocked = true;
        running = false;
        elapsed = 0f;
        selected = null;
        if (winPanel != null) winPanel.SetActive(false);
        if (timerText != null) timerText.text = FormatTime(0f);

        foreach (PackableItem item in items) if (item != null) Destroy(item.gameObject);
        foreach (CoolerSlot slot in slots) if (slot != null) Destroy(slot.gameObject);
        foreach (ListRow row in rows) if (row != null) Destroy(row.gameObject);
        items.Clear();
        slots.Clear();
        rows.Clear();

        int required = 0;
        foreach (PackEntry entry in shoppingList) required += entry.quantity;
        if (coolerCapacity < required)
            Debug.LogWarning($"[CoolerBoard] Capacity {coolerCapacity} is below the {required} items the list needs — this round can't be won.");

        for (int i = 0; i < coolerCapacity; i++)
        {
            CoolerSlot slot = Instantiate(slotPrefab, coolerRoot);
            slot.Setup(this);
            slots.Add(slot);
        }

        List<string> spawn = new List<string>();
        foreach (PackEntry entry in trayContents)
            for (int q = 0; q < entry.quantity; q++) spawn.Add(entry.itemId);
        Shuffle(spawn);

        foreach (string id in spawn)
        {
            PackItem data = FindItem(id);
            if (data == null)
            {
                Debug.LogWarning($"[CoolerBoard] Tray wants '{id}' but it isn't in the catalog.");
                continue;
            }
            PackableItem item = Instantiate(itemPrefab, trayRoot);
            item.Setup(this, data);
            items.Add(item);
        }

        foreach (PackEntry _ in shoppingList)
            rows.Add(Instantiate(listRowPrefab, listRoot));

        RefreshList();
        UpdateHud();

        yield return null;
        inputLocked = false;
        running = true;
    }

    // ---- Click routing ----

    public void ItemClicked(PackableItem item)
    {
        if (inputLocked || !running || item == null || item.IsAnimating) return;

        if (item.IsPacked)
        {
            Unpack(item);
            return;
        }

        if (selected == item)
        {
            selected.SetSelected(false);
            selected = null;
            return;
        }

        if (selected != null) selected.SetSelected(false);
        selected = item;
        selected.SetSelected(true);
        PlayClip(selectClip);
    }

    public void SlotClicked(CoolerSlot slot)
    {
        if (inputLocked || !running || slot == null) return;
        if (selected == null || !slot.IsEmpty) return;

        PackableItem item = selected;
        selected = null;
        StartCoroutine(PackRoutine(item, slot));
    }

    private IEnumerator PackRoutine(PackableItem item, CoolerSlot slot)
    {
        slot.Occupant = item;
        PlayClip(packClip);
        yield return item.MoveInto(slot);

        RefreshList();
        UpdateHud();
        CheckWin();
    }

    private void Unpack(PackableItem item)
    {
        if (item.Slot != null) item.Slot.Occupant = null;
        item.ReturnTo(trayRoot);
        PlayClip(unpackClip);

        RefreshList();
        UpdateHud();
    }

    // ---- Rules ----

    private void CheckWin()
    {
        foreach (PackEntry entry in shoppingList)
        {
            int packed = PackedCount(entry.itemId);
            if (requireExactPack ? packed != entry.quantity : packed < entry.quantity) return;
        }

        if (requireExactPack)
        {
            foreach (PackableItem item in items)
                if (item.IsPacked && !IsOnList(item.ItemId)) return;
        }

        Finish();
    }

    private void Finish()
    {
        running = false;
        inputLocked = true;
        PlayClip(winClip);

        if (winSummaryText != null) winSummaryText.text = $"Packed in {FormatTime(elapsed)}";
        if (winPanel != null) winPanel.SetActive(true);
    }

    // ---- Helpers ----

    private void RefreshList()
    {
        for (int i = 0; i < rows.Count && i < shoppingList.Count; i++)
        {
            PackEntry entry = shoppingList[i];
            PackItem data = FindItem(entry.itemId);
            string display = data != null ? data.displayName : entry.itemId;
            rows[i].Set(display, PackedCount(entry.itemId), entry.quantity);
        }
    }

    private void UpdateHud()
    {
        if (capacityText == null) return;
        int used = 0;
        foreach (CoolerSlot slot in slots) if (!slot.IsEmpty) used++;
        capacityText.text = $"{used}/{coolerCapacity}";
    }

    private int PackedCount(string itemId)
    {
        int count = 0;
        foreach (PackableItem item in items)
            if (item.IsPacked && item.ItemId == itemId) count++;
        return count;
    }

    private bool IsOnList(string itemId)
    {
        foreach (PackEntry entry in shoppingList)
            if (entry.itemId == itemId) return true;
        return false;
    }

    private PackItem FindItem(string id)
    {
        foreach (PackItem item in catalog)
            if (item.id == id) return item;
        return null;
    }

    private void PlayClip(AudioClip clip)
    {
        if (audioSource != null && clip != null) audioSource.PlayOneShot(clip);
    }

    private static string FormatTime(float seconds)
    {
        int total = Mathf.FloorToInt(seconds);
        return $"{total / 60:0}:{total % 60:00}";
    }

    private static void Shuffle(List<string> list)
    {
        for (int i = list.Count - 1; i > 0; i--)
        {
            int j = Random.Range(0, i + 1);
            (list[i], list[j]) = (list[j], list[i]);
        }
    }
}
