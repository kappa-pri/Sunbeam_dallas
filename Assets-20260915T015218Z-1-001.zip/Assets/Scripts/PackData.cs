using UnityEngine;

/// <summary>
/// One kind of thing you can pack. The id is what the shopping list matches on,
/// so keep ids unique and stable.
/// </summary>
[System.Serializable]
public class PackItem
{
    public string id = "WATER";
    public string displayName = "Water";

    [Tooltip("Optional. When set, this replaces the text label on the item.")]
    public Sprite icon;

    public Color tint = new Color(0.42f, 0.76f, 0.87f);

    public PackItem() { }

    public PackItem(string id, string displayName, string hexTint)
    {
        this.id = id;
        this.displayName = displayName;
        if (ColorUtility.TryParseHtmlString(hexTint, out Color parsed)) tint = parsed;
    }
}

/// <summary>
/// A quantity of one item id. Used both for what's on the counter and for what
/// the shopping list demands.
/// </summary>
[System.Serializable]
public class PackEntry
{
    public string itemId = "WATER";
    [Min(1)] public int quantity = 1;

    public PackEntry() { }

    public PackEntry(string itemId, int quantity)
    {
        this.itemId = itemId;
        this.quantity = quantity;
    }
}
