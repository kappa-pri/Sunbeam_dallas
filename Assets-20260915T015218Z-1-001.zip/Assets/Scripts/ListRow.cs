using TMPro;
using UnityEngine;
using UnityEngine.UI;

/// <summary>One line of the shopping list.</summary>
public class ListRow : MonoBehaviour
{
    [SerializeField] private TMP_Text nameText;
    [SerializeField] private TMP_Text countText;
    [SerializeField] private Image checkBox;

    [SerializeField] private Color pendingColor = new Color(0.07f, 0.27f, 0.35f);
    [SerializeField] private Color doneColor = new Color(0.24f, 0.75f, 0.55f);

    public void Set(string display, int packed, int required)
    {
        bool done = packed == required;

        if (nameText != null) nameText.text = display;
        if (countText != null)
        {
            countText.text = $"{packed}/{required}";
            countText.color = done ? doneColor : pendingColor;
        }
        if (checkBox != null) checkBox.color = done ? doneColor : new Color(1f, 1f, 1f, 0.35f);
    }
}
