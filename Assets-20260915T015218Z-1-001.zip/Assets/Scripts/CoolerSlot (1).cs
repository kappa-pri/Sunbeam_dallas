using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// One space in the cooler. Pulses while the player is holding an item so it's
/// always obvious where a click will land.
/// </summary>
[RequireComponent(typeof(Button))]
public class CoolerSlot : MonoBehaviour
{
    [SerializeField] private Image background;
    [Tooltip("Optional. Packed items are parented here. Defaults to this object.")]
    [SerializeField] private RectTransform contentRoot;

    [Header("Colours")]
    [SerializeField] private Color idleColor = new Color(1f, 1f, 1f, 0.22f);
    [SerializeField] private Color readyColor = new Color(1f, 0.78f, 0.35f, 0.80f);
    [SerializeField] private float pulseSpeed = 1.6f;

    public RectTransform ContentRoot => contentRoot != null ? contentRoot : (RectTransform)transform;
    public PackableItem Occupant { get; set; }
    public bool IsEmpty => Occupant == null;

    private CoolerBoard board;
    private Button button;

    private void Awake()
    {
        button = GetComponent<Button>();
        button.onClick.AddListener(HandleClick);
    }

    public void Setup(CoolerBoard owner)
    {
        board = owner;
        Occupant = null;
        if (background != null) background.color = idleColor;
    }

    private void Update()
    {
        if (background == null) return;

        bool ready = board != null && board.HasSelection && IsEmpty;
        if (ready)
        {
            float k = (Mathf.Sin(Time.unscaledTime * pulseSpeed * Mathf.PI) + 1f) * 0.5f;
            background.color = Color.Lerp(idleColor, readyColor, k);
        }
        else
        {
            background.color = idleColor;
        }
    }

    private void HandleClick()
    {
        if (board != null) board.SlotClicked(this);
    }
}
